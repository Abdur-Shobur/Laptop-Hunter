import React from 'react'

function Banner() {
  return <div>Banner</div>
}

export default Banner
