import React from 'react'

function MyWishList() {
  return <div>My WishList not complete yet </div>
}

export default MyWishList
