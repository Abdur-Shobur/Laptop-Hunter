import React from 'react'

function Pragarphone({ children }) {
  return <p className="text-2xl text-black font-bold mt-2 ">{children}</p>
}

export default Pragarphone
